The Windows version of TestDisk & PhotoRec should work under
- Windows Vista
- Windows 7 and later
- Windows Server 2008 and later

The Windows version of QPhotoRec should work under
- Windows 7 and later
- Windows Server 2008 and later

You can download it from https://www.cgsecurity.org/wiki/TestDisk_Download

TestDisk doesn't need to be installed, you only need to
- extract the files
- run testdisk_win.exe, photorec_win.exe or qphotorec_win.exe

TestDisk & PhotoRec documentation can be found online:
- https://www.cgsecurity.org/wiki/TestDisk
- https://www.cgsecurity.org/wiki/PhotoRec

TestDisk & PhotoRec 7.0 is the last version supporting Windows Server 2003.
TestDisk & PhotoRec 6.14 is the last version running on
- Windows NT 4
- Windows XP
- Windows Server 2000
